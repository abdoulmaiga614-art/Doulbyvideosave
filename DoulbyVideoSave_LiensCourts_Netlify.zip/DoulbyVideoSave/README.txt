DoulbyVideoSave

Déploiement Netlify :
1. Envoyez le CONTENU de ce dossier dans le dépôt GitHub (pas le fichier ZIP).
2. Le fichier netlify.toml doit rester à la racine du dépôt.
3. Le dossier netlify/functions doit être présent à la racine.
4. Dans Netlify, importez le dépôt GitHub et lancez le déploiement.

Ce site affiche les vidéos publiques intégrables. Il ne télécharge pas les vidéos et ne contourne pas les restrictions de TikTok.
