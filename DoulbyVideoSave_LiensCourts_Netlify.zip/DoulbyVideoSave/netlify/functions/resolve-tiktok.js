exports.handler = async function(event) {
  const raw = event.queryStringParameters && event.queryStringParameters.url;
  if (!raw) return json(400, { error: 'Lien manquant.' });
  let parsed;
  try { parsed = new URL(raw); } catch { return json(400, { error: 'Adresse invalide.' }); }
  if (!['tiktok.com','www.tiktok.com','vm.tiktok.com','vt.tiktok.com','m.tiktok.com'].includes(parsed.hostname)) {
    return json(400, { error: 'Seuls les liens TikTok sont acceptés.' });
  }
  try {
    const response = await fetch(parsed.toString(), { method: 'GET', redirect: 'follow', headers: { 'User-Agent': 'Mozilla/5.0' } });
    const finalUrl = response.url;
    const finalParsed = new URL(finalUrl);
    if (!finalParsed.hostname.endsWith('tiktok.com') || !/\/video\/\d+/.test(finalParsed.pathname)) {
      return json(422, { error: 'Impossible de reconnaître ce lien TikTok public.' });
    }
    return json(200, { url: finalUrl });
  } catch {
    return json(502, { error: 'TikTok ne permet pas de résoudre ce lien pour le moment.' });
  }
};
function json(statusCode, body) {
  return { statusCode, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }, body: JSON.stringify(body) };
}
